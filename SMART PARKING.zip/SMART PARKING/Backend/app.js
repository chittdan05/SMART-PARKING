const express = require("express");
const mongoose = require("mongoose");
const app = express();
const bodyParser = require("body-parser");
const { connectDB } = require("./config/db.config");
const userRouter = require("./controllers/user");
const handleError = require('./utils/errorHandler');
const { isLoggedIn } = require("./controllers/middleware");
const parkingRouter = require("./controllers/parking");
const paymentMethodRouter = require("./controllers/paymentMethod");
const bookingRouter = require("./controllers/booking");
const spaceRouter = require("./controllers/spaceRouter");
const cors = require('cors');
const reviewRouter = require("./controllers/review");
const adminRouter = require("./controllers/admin");

// Set body-parser
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use(cors())
// Connect Database

app.get('/', isLoggedIn, async (req, res) => {
  res.json({ message: 'Hello world!' })
})

app.use("/user", userRouter)
app.use("/parking", parkingRouter)
app.use("/paymentMethod", paymentMethodRouter)
app.use("/booking", bookingRouter)
app.use("/space", spaceRouter)
app.use("/review", reviewRouter)
app.use("/admin", adminRouter);

// Error handler

app.use((req, res, next) => {
  const error = new Error("Not Found")
  error.status = 404;
  next(error)
})

app.use((error, req, res, next) => {
  handleError(error, res);
})

mongoose.connect("mongodb://127.0.0.1:27017/26_node_internship")
  .then(() => console.log("Database connected..."))
  .catch(err => console.error("DB Connection Error:", err));

// ✅ Start Server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});