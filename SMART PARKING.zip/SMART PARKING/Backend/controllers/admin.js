// controllers/admin.js
const express = require('express');
const router = express.Router();
const User = require('../models/userSchema');
const Parking = require('../models/parkingSchema');
const Booking = require('../models/bookingSchema');
const Review = require('../models/reviewSchema');

// Get dashboard stats
router.get('/stats', async (req, res) => {
  try {
    const usersCount = await User.countDocuments();
    const ownersCount = await Parking.countDocuments();
    const bookingsCount = await Booking.countDocuments();
    const reviewsCount = await Review.countDocuments();
    res.json({ usersCount, ownersCount, bookingsCount, reviewsCount });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Delete user by ID
router.delete('/users/:id', async (req, res) => {
  try {
    const result = await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted', result });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// Delete parking owner by ID
router.delete('/owners/:id', async (req, res) => {
  try {
    const result = await Parking.findByIdAndDelete(req.params.id);
    res.json({ message: 'Parking owner deleted', result });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete owner' });
  }
});

module.exports = router;
