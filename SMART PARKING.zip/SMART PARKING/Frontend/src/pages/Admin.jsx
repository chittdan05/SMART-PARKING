import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    usersCount: 0,
    ownersCount: 0,
    bookingsCount: 0,
    reviewsCount: 0,
  });

  const [users, setUsers] = useState([]);
  const [owners, setOwners] = useState([]);

  const fetchStats = async () => {
    try {
      const res = await axios.get('/admin/stats');
      setStats(res.data);
    } catch (error) {
      console.error('Failed to fetch stats', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await axios.get('/admin/users');
      setUsers(res.data);
    } catch (error) {
      console.error('Failed to fetch users', error);
    }
  };

  const fetchOwners = async () => {
    try {
      const res = await axios.get('/admin/owners'); // Assuming you create this route or you can fetch from Parking model endpoint
      setOwners(res.data);
    } catch (error) {
      console.error('Failed to fetch owners', error);
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    try {
      await axios.delete(`/admin/users/${id}`);
      setUsers(users.filter(u => u._id !== id));
      fetchStats();
    } catch (error) {
      console.error('Failed to delete user', error);
    }
  };

  const deleteOwner = async (id) => {
    if (!window.confirm('Are you sure you want to delete this parking owner?')) return;
    try {
      await axios.delete(`/admin/owners/${id}`);
      setOwners(owners.filter(o => o._id !== id));
      fetchStats();
    } catch (error) {
      console.error('Failed to delete owner', error);
    }
  };

  useEffect(() => {
    fetchStats();
    fetchUsers();
    fetchOwners();
  }, []);

  return (
    <div>
      <section className="banner">
        <div className="overlay">
          <h1>
            Admin Dashboard <br />
            <span>Overview of your Smart Parking System</span>
          </h1>
          <div className="stats">
            <div className="stat-card">
              <h2>{stats.usersCount}</h2>
              <p>Users</p>
            </div>
            <div className="stat-card">
              <h2>{stats.ownersCount}</h2>
              <p>Parking Owners</p>
            </div>
            <div className="stat-card">
              <h2>{stats.bookingsCount}</h2>
              <p>Bookings</p>
            </div>
            <div className="stat-card">
              <h2>{stats.reviewsCount}</h2>
              <p>Reviews</p>
            </div>
          </div>
        </div>
      </section>

      <section className="admin-lists">
        <div className="list-container">
          <h3>Users</h3>
          {users.length === 0 ? (
            <p>No users found</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user._id}>
                    <td>{user.name || 'N/A'}</td>
                    <td>{user.email}</td>
                    <td>
                      <button className="btn-delete" onClick={() => deleteUser(user._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="list-container">
          <h3>Parking Owners</h3>
          {owners.length === 0 ? (
            <p>No parking owners found</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Owner Name</th>
                  <th>Parking Area</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {owners.map((owner) => (
                  <tr key={owner._id}>
                    <td>{owner.ownerName || 'N/A'}</td>
                    <td>{owner.parkingArea || 'N/A'}</td>
                    <td>
                      <button className="btn-delete" onClick={() => deleteOwner(owner._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
};

export default AdminDashboard;
