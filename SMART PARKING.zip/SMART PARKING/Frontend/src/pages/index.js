import Home from "./Home";
import Layout from "./Layout";
import Parking from "./Parking";
import NoPage from "./NoPage";

export { Layout, Home, Parking, NoPage }